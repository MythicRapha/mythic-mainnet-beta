# Mythic CLI

Command-line interface for the Mythic L2 blockchain.

## Install

```bash
sh -c "$(curl -sSfL https://mythic.sh/install.sh)"
```

Or install manually:

```bash
git clone https://github.com/MythicL2/mythic-cli.git
cd mythic-cli
npm install
npm run build
npm link
```

## Usage

```bash
mythic --version                    # Show version
mythic config set --url <RPC_URL>   # Set RPC endpoint
mythic config get                   # Show current config
mythic balance                      # Show SOL + MYTH balance
mythic balance <ADDRESS>            # Show balance of address
mythic transfer <TO> <AMOUNT>       # Transfer SOL
mythic transfer <TO> <AMOUNT> --token MYTH  # Transfer MYTH tokens
mythic airdrop <AMOUNT>             # Request testnet airdrop
mythic program deploy <FILE>        # Deploy a program
mythic program show <PROGRAM_ID>    # Show program info
mythic keygen new                   # Generate new keypair
mythic keygen pubkey                # Show public key
mythic address                      # Show current wallet address
mythic slot                         # Get current slot
mythic block-height                 # Get block height
mythic tps                          # Show current TPS
mythic validators                   # List validators
mythic bridge status                # Show bridge status
mythic bridge deposit <AMOUNT>      # Bridge from L1 to L2
mythic compute list                 # List available compute nodes
mythic compute rent <NODE_ID>       # Rent compute
mythic help                         # Show all commands
```

## Configuration

Config is stored at `~/.mythic/config.yml`:

```yaml
rpc_url: https://rpc.mythic.sh
keypair_path: ~/.config/solana/id.json
commitment: confirmed
```

## Requirements

- Node.js >= 18
- Solana CLI (for program deployment and key management)

## License

MIT
